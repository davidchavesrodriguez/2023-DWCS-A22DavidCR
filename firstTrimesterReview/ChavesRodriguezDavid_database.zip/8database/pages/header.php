<?php
echo '<header id="header">';
echo '<img src="../images/shopLogo.jpeg" alt="Shop Logo" id="shopLogo">';
echo "<h1>Corente's World</h1>";
echo '</header>';

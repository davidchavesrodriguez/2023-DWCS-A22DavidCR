<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sidebar</title>
</head>

<body>
    <div id="sidebar">
        <h2>Paesent scelerisque</h2>
        <ul>
            <li><a href="#">DIV with ID sidebar</a></li>
            <li><a href="#">Etiam rhoncus volutpat erat</a></li>
            <li><a href="#">Donec dictum metus in sapien</a></li>
        </ul>
    </div>
</body>

</html>
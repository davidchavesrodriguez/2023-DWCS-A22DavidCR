<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logo</title>
</head>

<body>
    <div id="logo">
        <h1><a href="#">PHP</a></h1>
        <p>template design by <a href="http://www.freecsstemplates.org">FCT</a></p>
    </div>
</body>

</html>
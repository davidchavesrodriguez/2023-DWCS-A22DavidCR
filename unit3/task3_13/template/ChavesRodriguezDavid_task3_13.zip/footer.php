<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer</title>
</head>

<body>
    <div id="footer">
        <p>Copyright (c) 2012 meusitio.com. All rights reserved. Design by <a href="http://www.freecsstemplates.org">FCT</a>.</p>
    </div>
</body>

</html>